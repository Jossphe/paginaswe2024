document.addEventListener('DOMContentLoaded', () => {
    console.log('Página cargada correctamente');
});


//para redirigir desde el botón
function redirectToCaracteristicas() {
    window.location.href = 'caracteristicas.html';
}

